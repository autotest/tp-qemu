#ifndef _TOOLS_ASM_EXPORT_H
#define _TOOLS_ASM_EXPORT_H

#define EXPORT_SYMBOL(x)
#define EXPORT_SYMBOL_GPL(x)

#endif /* _TOOLS_ASM_EXPORT_H */
