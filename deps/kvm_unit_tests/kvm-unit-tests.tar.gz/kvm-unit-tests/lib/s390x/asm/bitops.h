#ifndef _ASMS390X_BITOPS_H_
#define _ASMS390X_BITOPS_H_

#ifndef _BITOPS_H_
#error only <bitops.h> can be included directly
#endif

#define BITS_PER_LONG	64

#endif
