const char GIT_Version[] = "git:v4.3.3";
const char *git_version(void) {
    return GIT_Version;
}
