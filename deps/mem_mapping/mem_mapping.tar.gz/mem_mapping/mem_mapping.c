/*
 * test suite mmap [-a] [-s] [-f <filename>] -l <size>] -k -t <sleep_time>
 *
 * -a: Anonymous mapping
 * -f: File based mapping
 * -s  Shared anonymous mapping
 * -p: Private mapping
 * -l: Length of memory to be mapped
 * -k: Stop at various stages
 * -t: Program sleep time
 *
 * For example:
 * 1. PRIVATE FILE MAPPING
 *    dd if=/dev/zero of=/var/tmp/mem_file bs=1M count=51200
 *    ./mem_mapping -f /var/tmp/mem_file -p -l 30G -t 60s
 * 2. SHARED FILE MAPPING
 *    dd if=/dev/zero of=/var/tmp/mem_file bs=1M count=51200
 *    ./mem_mapping -f /var/tmp/mem_file -s -l 30G -t 60s
 * 3. PRIVATE ANONYMOUS MAPPING
 *    ./mem_mapping -a -p -l 30G -t 60s
 * 4. SHARED ANONYMOUS MAPPING
 *    ./mem_mapping -a -s -l 30G -t 60s
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <errno.h>
#include <pthread.h>

void *thread_body(void *arg) {
    printf("thread: pid = %d, thread_id = %lu\n", getpid(), pthread_self());
    return NULL;
}
struct mmap_struct {
    int		        page_size;
    int		        fd;
    int		        flags;
    void		*buf;
    unsigned long	len;
    int		        key_break;
};

#define MMAP_DEFAULT_SIZE	0x200000	/* 2MB */

static int util_misc_key_press(int enable, const char *prefix, const char *desc)
{
    int c;
    
    if (!enable)
        return 0;
    
    fprintf(stdout, "%s%s\n", prefix, desc);
    scanf("%c", &c);
    
    return c;
}

static unsigned long util_memory_parse_size(char *args)
{
    char *nptr, *p = NULL;
    unsigned long factor = 1, size = 0;
    
    if (!strlen(args))
        return 0;
    
    nptr = (char *)malloc(strlen(args) + 1);
    if (!nptr)
        return 0;
    
    memset(nptr, 0, strlen(args) + 1);
    strcpy(nptr, args);
    
    if ((p = strstr(nptr, "G")) || (p = strstr(nptr, "g")))
        factor = 0x40000000;
    else if ((p = strstr(nptr, "M")) || (p = strstr(nptr, "m")))
        factor = 0x100000;
    else if ((p = strstr(nptr, "K")) || (p = strstr(nptr, "k")))
        factor = 0x400;
    
    if (p) *p = '\0';
    size = factor * strtoul(nptr, NULL, 0);
    
    free(nptr);
    return size;
}

static unsigned long util_time_sleep(char *args)
{
    char *nptr, *p = NULL;
    unsigned long factor = 1, time_sleep = 3600;
    
    if (!strlen(args))
        return 0;
    
    nptr = (char *)malloc(strlen(args) + 1);
    if (!nptr)
        return 0;
    
    memset(nptr, 0, strlen(args) + 1); 
    strcpy(nptr, args);
    
    if ((p = strstr(nptr, "H")) || (p = strstr(nptr, "h")))
        factor = 3600;
    else if ((p = strstr(nptr, "M")) || (p = strstr(nptr, "m")))
        factor = 60;
    else if ((p = strstr(nptr, "S")) || (p = strstr(nptr, "s")))
        factor = 1;
    
    if (p) *p = '\0';
    time_sleep = factor * strtoul(nptr, NULL, 0);
    
    free(nptr);
    return (int)time_sleep;
}


static void usage(void)
{
    fprintf(stdout, "testsuite mmap [-a] [-s] [-f <filename>] -l <size>] -k -t <sleep_time>\n");
    fprintf(stdout, "\n");
    fprintf(stdout, "-a: Anonymous mapping\n");
    fprintf(stdout, "-f: File based mapping\n");
    fprintf(stdout, "-s  Shared anonymous mapping\n");
    fprintf(stdout, "-p: Private mapping\n");
    fprintf(stdout, "-l: Length of memory to be mapped\n");
    fprintf(stdout, "-k: Stop at various stages\n");
    fprintf(stdout, "-t: Program sleep time\n");
    fprintf(stdout, "\n");
}

static void mmap_init_data(struct mmap_struct *m)
{
    m->page_size	= getpagesize();
    m->fd		= -1;
    m->flags		= 0;
    m->buf		= (void *)-1;
    m->len		= MMAP_DEFAULT_SIZE;
    m->key_break	= 0;
}

int main(int argc, char **argv)
{
    struct mmap_struct m;
    int opt, c, i, sleep_time=3600;
    void * thread_result;
    
    
    mmap_init_data(&m);
    
    while ((opt = getopt(argc, argv, "af:spl:kh:t:")) != -1) {
        switch (opt) {
            case 'a':
                m.flags |= MAP_ANONYMOUS;
                break;
            case 'f':
                m.fd = open(optarg, O_RDWR);
                if (m.fd < 0) {
                    fprintf(stderr, "Unable to open <%s>\n", optarg);
                }
                break;
            case 's':
                m.flags |= MAP_SHARED;
                break;
            case 'p':
                m.flags |= MAP_PRIVATE;
                break;
            case 'l':
                m.len = util_memory_parse_size(optarg);
                break;
            case 'k':
                m.key_break = 1;
                break;
            case 't':
                sleep_time = util_time_sleep(optarg);
                break;
	    case 'h':	
            default:
                usage();
        }
    }
    
    /* mmap */
    m.buf = mmap(NULL, m.len, PROT_READ | PROT_WRITE, m.flags, m.fd, 0);
    if (m.buf == (void *)-1) {
        fprintf(stdout, "Unable do mmap()\n");
    }
    
    /* Write */
    memset(m.buf, 0, m.len);
    
    /* The program will hold memory for sleep_times */
    sleep(sleep_time);
    
    return 0;
}

