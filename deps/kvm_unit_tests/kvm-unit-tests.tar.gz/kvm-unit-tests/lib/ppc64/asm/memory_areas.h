#ifndef _ASMPPC64_MEMORY_AREAS_H_
#define _ASMPPC64_MEMORY_AREAS_H_

#include <asm-generic/memory_areas.h>

#endif
